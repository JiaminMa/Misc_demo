#ifndef _USB_CORE_H_
#define _USB_CORE_H_

#include "type.h"
#include "uart.h"
#include "PDIUSBD12.h"

#define GET_STATUS         0
#define CLEAR_FEATURE      1
#define SET_FEATURE        3
#define SET_ADDRESS        5
#define GET_DESCRIPTOR     6
#define SET_DESCRIPTOR     7
#define GET_CONFIGURATION  8
#define SET_CONFIGURATION  9
#define GET_INTERFACE      10
#define SET_INTERFACE      11
#define SYNCH_FRAME        12

#define DEVICE_DESCRIPTOR         1
#define CONFIGURATION_DESCRIPTOR  2
#define STRING_DESCRIPTOR         3
#define INTERFACE_DESCRIPTOR      4
#define ENDPOINT_DESCRIPTOR       5
#define REPORT_DESCRIPTOR         0x22

#define SET_IDLE 0x0A

extern uint8 config_val;
extern uint8 ep1_in_is_busy;

void delay_xms(uint16);
void usb_disconnect(void);
void usb_connect(void);
void usb_bus_suspend(void);
void usb_bus_reset(void);
void usb_ep0_out(void);
void usb_ep0_in(void);
void usb_ep1_out(void);
void usb_ep1_in(void);
void usb_ep2_out(void);
void usb_ep2_in(void);

#define USB_STD_IN_REQUEST 0
#define USB_CLASS_IN_REQUEST 1
#define USB_VENDOR_IN_REQUEST 2

#define USB_STD_OUT_REQUEST 0
#define USB_CLASS_OUT_REQUEST 1
#define USB_VENDOR_OUT_REQUEST 2

#define LANGUAGE_ID 0
#define MANUFATURE 1
#define PRODUCT	2
#define SERIAL_NUMBER 3

/*Descriptors*/

#ifdef CONFIG_USB_MOUSE
#define DEVICE_DESC_LEN 18
#define REPORT_DESC_LEN 52
#define CONFIG_DESC_LEN 9
#define INTERF_DESC_LEN 9
#define HID_DESC_LEN 9
#define ENDP_DESC_LEN 7
#define CONFIG_DESC_ALL_LEN (CONFIG_DESC_LEN + INTERF_DESC_LEN + \
            HID_DESC_LEN + ENDP_DESC_LEN)
#define MANU_STR_DESC_LEN 82
#define LANGUAGE_ID_STR_DESC_LEN 4
#define PRODUCT_STR_DESC 34
#define SERIAL_NUM_STR_DESC 22
#endif /*CONFIG_USB_MOUSE*/


#ifdef CONFIG_USB_KEYBOARD
#define DEVICE_DESC_LEN 18
#define REPORT_DESC_LEN 65
#define CONFIG_DESC_LEN 9
#define INTERF_DESC_LEN 9
#define HID_DESC_LEN 9
#define ENDP_DESC_LEN 7
#define CONFIG_DESC_ALL_LEN (CONFIG_DESC_LEN + INTERF_DESC_LEN + \
            HID_DESC_LEN + ENDP_DESC_LEN + ENDP_DESC_LEN)
#define MANU_STR_DESC_LEN 82
#define LANGUAGE_ID_STR_DESC_LEN 4
#define PRODUCT_STR_DESC 34
#define SERIAL_NUM_STR_DESC 22
#endif /*CONFIG_USB_KEYBOARD*/


#ifdef CONFIG_USB_SERIAL
#define DEVICE_DESC_LEN 18
#define REPORT_DESC_LEN 65
#define CONFIG_DESC_LEN 9
#define INTERF_DESC_LEN 9
#define HID_DESC_LEN 9
#define ENDP_DESC_LEN 7
#define CONFIG_DESC_ALL_LEN 9 + 9 + 5 + 5 + 4 + 5 + 7 + 9 + 7 + 7
#define MANU_STR_DESC_LEN 82
#define LANGUAGE_ID_STR_DESC_LEN 4
#define PRODUCT_STR_DESC 38
#define SERIAL_NUM_STR_DESC 22
#define GET_LINE_CODING         0x21
#define SERIAL_STATE            0x20
#define SET_LINE_CODING         0x20
#define SET_CONTROL_LINE_STATE  0x22
#define SEND_BREAK              0x23
#endif /*CONFIG_USB_SERIAL*/

#define SET_LINE_CODING         0x20
extern code uint8 device_desc[DEVICE_DESC_LEN];
extern code uint8 report_desc[REPORT_DESC_LEN];
extern code uint8 config_desc[CONFIG_DESC_ALL_LEN];
extern code uint8 language_id_str_desc[LANGUAGE_ID_STR_DESC_LEN];
extern code uint8 manu_str_desc[MANU_STR_DESC_LEN];
extern code uint8 product_str_desc[PRODUCT_STR_DESC];
extern code uint8 serial_num_str_desc[SERIAL_NUM_STR_DESC];

#endif