#ifndef __CONFIG_H__
#define __CONFIG_H__

#define Fclk      22118400UL
#define BitRate   9600UL
#define DEBUG

//#define CONFIG_USB_MOUSE
//#define CONFIG_USB_KEYBOARD
#define CONFIG_USB_SERIAL
#endif