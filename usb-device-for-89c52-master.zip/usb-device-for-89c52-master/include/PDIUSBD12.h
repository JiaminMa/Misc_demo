#ifndef __PDIUSBD12_H__
#define __PDIUSBD12_H__

#include <AT89X52.h>
#include "type.h"
#include "uart.h"

typedef enum {
	COMMAND,
	DATA,
} d12_data_type;

#define D12_COMMAND_ADD 1
#define D12_DATA_ADD 0

#define D12_DATA 	P0
#define D12_A0		P3_5
#define D12_WR		P3_6
#define D12_RD		P3_7
#define D12_INT		P3_2

#define D12_SET_COMMAND_ADDR() 	D12_A0 = D12_COMMAND_ADD
#define D12_SET_DATA_ADDR()		D12_A0 = D12_DATA_ADD

#define D12_SET_WR()	D12_WR = 1
#define D12_CLR_WR() 	D12_WR = 0
#define D12_SET_RD()	D12_RD = 1
#define D12_CLR_RD()	D12_RD = 0

#define D12_GET_INT_PIN()	D12_INT

#define D12_GET_DATA()		D12_DATA
#define D12_SET_DATA(value)	D12_DATA = (value)

#define D12_SET_PORT_IN()	D12_DATA = 0xFF
#define D12_SET_PORT_OUT()

#define READ_ID	0xFD
#define D12_SET_MODE  0xF3
#define READ_INTERRUPT_REGISTER  0xF4
#define D12_READ_BUFFER 0xF0
#define D12_CLEAR_BUFFER 0xF2
#define D12_ACKNOWLEDGE_SETUP 0xF1
#define D12_VALIDATE_BUFFER 0xFA
#define D12_WRITE_BUFFER 0xF0
#define D12_SET_ADDRESS_ENABLE 0xD0
#define D12_SET_ENDPOINT_ENABLE 0xD8

/*Function*/
void d12_write_command(uint8);
void d12_write_byte(uint8);
uint8 d12_read_byte(void);
uint16 d12_read_id(void);
void d12_select_endpoint(uint8);
uint8 d12_read_ep_buffer(uint8, uint8, uint8 *);
void d12_clear_buffer(void);
void d12_acknowledge_setup(void);
uint8 d12_read_ep_last_stat(uint8); 
void d12_validate_buffer(void);
uint8 d12_write_ep_buffer(uint8, uint8, uint8 *);
void d12_set_address(uint8 addr);
void d12_set_ep_enable(uint8);
#endif /*__PDIUSBD12_H__*/