#ifndef __UART_C__
#define __UART_C__

#include "type.h"
#include "config.h"

void init_uart(void);
void puts(uint8 * pd);
void putc(uint8 d);
void putint(uint32 x);
void putshort(uint16 x);
void puthex(uint8 x);
uint32 uart_set_bit_rate(uint32 bit_rate);
#endif
