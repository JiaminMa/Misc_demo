#ifndef __MY_TYPE_H__
#define __MY_TYPE_H__

typedef unsigned char uint8;
typedef unsigned short int uint16;
typedef unsigned long int uint32;
typedef signed char int8;
typedef signed short int int16;
typedef signed long int int32;
#define uint64 unsigned long long int
#define int64 signed long long int 

#endif
