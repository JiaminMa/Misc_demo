#include "usb_core.h"
#include "led.h"

#define M_BUF_SIZE 16
#define EP0_OUT 0
idata uint8 m_buffer[M_BUF_SIZE];
uint8 config_val;
uint8 ep1_in_is_busy;

static uint8 bm_request_type;
static uint8 b_request;
static uint16 w_value;
static uint16 w_index;
static uint16 w_length;
static uint8 *p_send_data;
static uint16 send_length;
static uint8 need_zero_packet;
static uint8 line_coding[7]={0x80, 0x25, 0x00,
                0x00, 0x00, 0x00, 0x08};

#ifdef CONFIG_USB_SERIAL
void usb_ep0_data_out(void)
{
    if ((bm_request_type == 0x21) && (b_request == SET_LINE_CODING)) {
        uint32 bit_rate;
        uint8 length;
        
        length = d12_read_ep_buffer(0, 7, line_coding);
        d12_clear_buffer();
        if (length == 7) {
            bit_rate = line_coding[3];
            bit_rate = (bit_rate << 8) + line_coding[2];
            bit_rate = (bit_rate << 8) + line_coding[1];
            bit_rate = (bit_rate << 8) + line_coding[0];
            
            puts("USB Buardrate is ");
            putint(bit_rate);
            puts("bps\n");
        }
        bit_rate = uart_set_bit_rate(bit_rate);
        line_coding[0] = bit_rate & 0xff;
        line_coding[1] = (bit_rate >> 8) & 0xff;
        line_coding[2] = (bit_rate >> 16) & 0xff;
        line_coding[3] = (bit_rate >> 24) & 0xff;
        line_coding[4] = 0x00;
        line_coding[5] = 0x00;
        line_coding[6] = 0x08;
        d12_write_ep_buffer(1, 0, 0);
    } else {
        d12_read_ep_buffer(0, 16, m_buffer);
        d12_clear_buffer();
    }
        
}
#endif /*CONFIG_USB_SERIAL*/


void delay_xms(uint16 x) 
{
    uint16 i;
    uint16 j;
    for (i = 0; i < x; i++) {
        for (j = 0; j < 227; j++);
    }
}

void usb_disconnect()
{
    puts("Disconnect USB\n");
    
    d12_write_command(D12_SET_MODE);
    d12_write_byte(0x06);
    d12_write_byte(0x47);
    delay_xms(1000);
}

void usb_connect(void) 
{
    puts("Connect USB\n");
    
    d12_write_command(D12_SET_MODE);
    d12_write_byte(0x16);
    d12_write_byte(0x47);
    delay_xms(1000);
}

void usb_bus_suspend(void)
{
    puts("#####usb_bus_suspend#####\n");
}

void usb_bus_reset(void)
{
    puts("####usb_bus_reset####\n");
    ep1_in_is_busy = 0;
}

static void usb_ep0_send_data()
{
    if (send_length > device_desc[7]) {
        d12_write_ep_buffer(1, device_desc[7], p_send_data);
        send_length -= device_desc[7];
        p_send_data += device_desc[7];
    } else {
        if (send_length != 0) {
            d12_write_ep_buffer(1, send_length, p_send_data);
            send_length = 0;
        } else {
            if (need_zero_packet == 1) {
                d12_write_ep_buffer(1, 0, p_send_data);
                need_zero_packet = 0;
            }
        }
    }
}

static void handle_std_out_request()
{
    switch(b_request) {
    
    case CLEAR_FEATURE:
        puts("clear feature\n");
        break;
    
    case SET_ADDRESS:
        puts("set address:");
        puthex(w_value & 0xff);
        puts("\n");
        d12_set_address(w_value & 0xff);
        send_length = 0;
        need_zero_packet = 1;
        usb_ep0_send_data();
        break;
     
    case SET_CONFIGURATION:
        puts("set configuration\n");
        config_val = w_value & 0xFF;
        d12_set_ep_enable(w_value & 0xff);
        send_length = 0;
        need_zero_packet = 1;
        usb_ep0_send_data();
        break;
    
    case SET_DESCRIPTOR:
        puts("set descriptor\n");
        break;
    
    case SET_FEATURE:
        puts("set feature\n");
        break;
    
    case SET_INTERFACE:
        puts("set interface\n");
        break;
    
    default:
        puts("Error:Undefined standard output request");
        break;
    }/*switch(b_request)*/
}

static void handle_get_str_desc()
{
    switch(w_value & 0xff) {
    case LANGUAGE_ID:
        puts("Language ID\n");
        p_send_data = language_id_str_desc;
        send_length = language_id_str_desc[0];
        break;
    
    case MANUFATURE:
        puts("MANUFATURE ID\n");
        p_send_data = manu_str_desc;
        send_length = manu_str_desc[0];
        break;        
    
    case PRODUCT:
        puts("PRODUCT ID\n");
        p_send_data = product_str_desc;
        send_length = product_str_desc[0];
        break;    
    
    case SERIAL_NUMBER:
        puts("SERIAL_NUMBER\n");
        p_send_data = serial_num_str_desc;
        send_length = serial_num_str_desc[0];
        break;    
    
    default:
        puts("Unknown index\n");
        send_length = 0;
        need_zero_packet = 1;
        break;
    }

}

static void handle_get_descriptor()
{
    switch((w_value >> 8) & 0xff) {
    case DEVICE_DESCRIPTOR:
        puts("Device descriptor\n");
        p_send_data = device_desc;
        if (w_length > device_desc[0]) {
            send_length = device_desc[0];
            if (send_length % device_desc[7] == 0) {
                need_zero_packet = 1;
            }     
        } else {
                send_length = w_length;
        }
        usb_ep0_send_data();
        break;
        
    case CONFIGURATION_DESCRIPTOR:
        puts("Configuration descriptor\n");
        p_send_data = config_desc;
        send_length = config_desc[3];
        send_length = send_length * 256 + config_desc[2];
    
        if (w_length > send_length) {
            if (send_length % device_desc[7] == 0) {
                need_zero_packet = 1;
            }
        } else {
            send_length = w_length;
        }
        usb_ep0_send_data();
        break;
    
    case STRING_DESCRIPTOR:
        puts("String descriptor----");
        handle_get_str_desc();
        if (w_length > send_length) {
            if (send_length % device_desc[7] == 0) {
                need_zero_packet = 1;
            }
        } else {
            send_length = w_length;
        }
        usb_ep0_send_data();
        break;
        
    default:
        puts("Other descriptor, desc code:");
        puthex((w_value >> 8) & 0xff);
        puts("\n");
        break;
    }
}

static void handle_std_in_request()
{
    switch(b_request) {
        
    case GET_CONFIGURATION:
        puts("get configuration.\n");
        break;
    
    case GET_DESCRIPTOR:
        puts("get descriptor---");
        handle_get_descriptor();
        break;
    
    case GET_INTERFACE:
        puts("get interface.\n");
        break;
    
    case GET_STATUS:
        puts("get status.\n");
        break;
    
    case SYNCH_FRAME:
        puts("sync frame.\n");
        break;
    
    default:
        puts("Error: undefined standard input request\n");
        break;
    } /*switch(b_request)*/    
}

static void handle_class_out_request()
{
    switch(b_request) {
    case SET_IDLE:
        puts("Set Idle.\n");
        send_length = 0;
        need_zero_packet =1;
        usb_ep0_send_data();
        break;
    case SET_CONTROL_LINE_STATE:
        puts("SET_CONTROL_LINE_STATE\n");
        send_length = 0;
        need_zero_packet = 1;
        usb_ep0_send_data();
        break;
    case SET_LINE_CODING:
        puts("SET_LINE_CODING\n");
        break;
    default:
        puts("Unkown class out request\n");
        break;
    }
}

static void handle_class_in_request()
{
    switch(b_request) {
    case GET_LINE_CODING:
        puts("GET_LINE_CODING\n");
        send_length = 0x07;
        p_send_data = line_coding;
        break;
    case SERIAL_STATE:
        puts("SERIAL_STATE\n");
        send_length = 0;
        need_zero_packet = 1;
        break;
    default:
        puts("Unknown class request\n");
        send_length = 0;
        need_zero_packet = 1;
        break;
    }
    
    if (w_length > send_length) {
        if (send_length % device_desc[7] == 0) {
            need_zero_packet = 1;
        }
    } else {
        send_length = w_length;
    }
    
    usb_ep0_send_data();
}

void usb_ep0_out(void)
{
    uint8 i = 0, j = M_BUF_SIZE ;
    puts("####usb_ep0_out####\n");
    /*If the 5th bit is 1, it the setup package*/
    if (d12_read_ep_last_stat(0) & 0x20) {
        d12_read_ep_buffer(EP0_OUT, M_BUF_SIZE, m_buffer);
        d12_acknowledge_setup();
        d12_clear_buffer();
        
        bm_request_type = m_buffer[0];
        b_request = m_buffer[1];
        w_value = m_buffer[2] + (((uint16)m_buffer[3] << 8));
        w_index = m_buffer[4] + (((uint16)m_buffer[5] << 8));
        w_length = m_buffer[6] + (((uint16)m_buffer[7] << 8));
        
        if ((bm_request_type & 0x80) == 0x80) {
            
            switch(bm_request_type >> 5 & 0x03) {
                
            case USB_STD_IN_REQUEST:
                puts("USB Standard input request:");
                handle_std_in_request();
                break;
            case USB_CLASS_IN_REQUEST:
                puts("USB class input request:");
                handle_class_in_request();
                break;
            case USB_VENDOR_IN_REQUEST:
                puts("USB vendor input request:\n");
                break;
            default:
                puts("Error: undefined input request\n");
                break;
            }
        } else { 
            switch((bm_request_type >> 5) & 0x03) {
            
            case USB_STD_OUT_REQUEST:
                puts("USB Standard output request:");
                handle_std_out_request();
                break;
            
            case USB_CLASS_OUT_REQUEST:
                puts("USB Class output request----");
                handle_class_out_request();
                break;
            
            case USB_VENDOR_OUT_REQUEST:
                puts("USB Vendor output request\n");
                break;
            default:
                puts("Error:Undefined output request\n");
            } 
        }
            
    } else {

#ifdef CONFIG_USB_SERIAL
        usb_ep0_data_out();
#elif
        d12_read_ep_buffer(EP0_OUT, M_BUF_SIZE, m_buffer);
        d12_clear_buffer();      
#endif
    } 
}

void usb_ep0_in(void)
{
    puts("####usb_ep0_in####\n");
    d12_read_ep_last_stat(1);
    usb_ep0_send_data();
}

void usb_ep1_out(void)
{
    uint8 buf[1];
    puts("####usb_ep1_out####\n"); 
#ifdef CONFIG_USB_KEYBOARD
    d12_read_ep_last_stat(2);
    d12_read_ep_buffer(2, 1, buf);
    d12_clear_buffer();
    LEDs = ~buf[0];
#endif    
}

void usb_ep1_in(void)
{
    puts("####usb_ep1_in####\n");    
    d12_read_ep_last_stat(3);
    ep1_in_is_busy = 0;
}

void usb_ep2_out(void)
{
    puts("####usb_ep2_out####\n");        
}

void usb_ep2_in(void)
{
    puts("####usb_ep2_in####\n");            
}
