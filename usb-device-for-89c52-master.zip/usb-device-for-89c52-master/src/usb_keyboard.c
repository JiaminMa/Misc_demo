#include "config.h"
#ifdef CONFIG_USB_KEYBOARD
#include "usb_core.h"
#include "key.h"

code uint8 device_desc[DEVICE_DESC_LEN] =
{
    0x12, /*bLength:18(0x12)*/
    0x01, /*bDescriptorType: device_desc:0x01*/
    
    0x10, /*USB1.1:0x0110*/
    0x01,
    
    0x00, /*bDeviceClass:0*/
    
    0x00, /*bDeviceSubClass:0*/
    
    0x00, /*bDeviceProtocal*/
    
    0x10, /*bMaxPacketSize, PDIUSBDS12 ep0 max is 16 bytes*/
    
    0x88, /*Vendor ID, 0x8888 for test only*/
    0x88,
    
    0x02, /*idProduct:0x0001*/
    0x00,
    
    0x00, /*bcdDevice*/
    0x01,
    
    0x01, /*iManufactuer*/
    
    0x02, /*iProduct*/
    
    0x03, /*Serial Number*/
    
    0x01, /*bNumConfiguration*/
};

code uint8 report_desc[REPORT_DESC_LEN] =
{

    0x05, 0x01, // USAGE_PAGE (Generic Desktop)
    0x09, 0x06, // USAGE (Keyboard)
    0xa1, 0x01, // COLLECTION (Application)
    0x05, 0x07, //     USAGE_PAGE (Keyboard/Keypad
    0x19, 0xe0, //     USAGE_MINIMUM (Keyboard LeftControl)
    0x29, 0xe7, //     USAGE_MAXIMUM (Keyboard Right GUI)
    0x15, 0x00, //     LOGICAL_MINIMUM (0)
    0x25, 0x01, //     LOGICAL_MAXIMUM (1)
    0x95, 0x08, //     REPORT_COUNT (8)
    0x75, 0x01, //     REPORT_SIZE (1)
    0x81, 0x02, //     INPUT (Data,Var,Abs)
    0x95, 0x01, //     REPORT_COUNT (1)
    0x75, 0x08, //     REPORT_SIZE (8)
    0x81, 0x03, //     INPUT (Cnst,Var,Abs)
    0x95, 0x06, //   REPORT_COUNT (6)
    0x75, 0x08, //   REPORT_SIZE (8)
    0x15, 0x00, //   LOGICAL_MINIMUM (0)
    0x25, 0xFF, //   LOGICAL_MAXIMUM (255)
    0x05, 0x07, //   USAGE_PAGE (Keyboard/Keypad)
    0x19, 0x00, //   USAGE_MINIMUM (Reserved (no event indicated))
    0x29, 0x65, //   USAGE_MAXIMUM (Keyboard Application)
    0x81, 0x00, //     INPUT (Data,Ary,Abs)
    0x25, 0x01, //     LOGICAL_MAXIMUM (1)
    0x95, 0x05, //   REPORT_COUNT (5)
    0x75, 0x01, //   REPORT_SIZE (1)
    0x05, 0x08, //   USAGE_PAGE (LEDs)
    0x19, 0x01, //   USAGE_MINIMUM (Num Lock)
    0x29, 0x05, //   USAGE_MAXIMUM (Kana)
    0x91, 0x02, //   OUTPUT (Data,Var,Abs)
    0x95, 0x01, //   REPORT_COUNT (1)
    0x75, 0x03, //   REPORT_SIZE (3)
    0x91, 0x03, //   OUTPUT (Cnst,Var,Abs)
    0xc0        // END_COLLECTION
};
    

code uint8 config_desc[CONFIG_DESC_ALL_LEN] =
{
    /**********Configuration Descriptor********/
    0x09,             /*b_length of config desc*/
    0x02,             /*b_descriptor_type, 0x02*/
    sizeof(config_desc) & 0xff,    /*w_total_length*/
    (sizeof(config_desc) >> 8) & 0xff,
    0x01,            /*b_num_interface, interface num in config desc*/
    0x01,            /*b_configuration*/
    0x00,             /*i_configration, string desc index*/
    0x80,            /*bm_attribtute, bus power supply, no suspend-resume*/
    0x32,            /*b_max_power, the max power need by the device*/
    
    /**********Interface Descriptor********/
    0x09,     /*b_length*/
    0x04,     /*b_descritpor_type*/
    0x00,     /*b_interface_number*/
    0x00,     /*b_alternate_setting*/
    0x02,    /*b_number_endpoints, non-zero ep number*/
    0x03,    /*b_interface_class, HID Class is 0x03*/
    0x01,    /*b_interface_sub_class*/
    0x01,     /*b_interface_protocal,keyboard:0x01, keyboard:0x02*/
    0x00,      /*i_configuration*/
    
    /**********HID Descriptor********/
    0x09,     /*b_length*/
    0x21,     /*b_desc_type*/
    0x10,    /*bcdHID Protocal, 0x0110*/
    0x01,
    0x21,    /*b_country_code*/
    0x01,     /*b_number_descriptor, num of next level desc*/
    0x22,     /*b_desc_type, next level Report desc:0x22*/
    sizeof(report_desc) & 0xff,
    (sizeof(report_desc) >> 8) & 0xff,

    /**********Input Endpoint Descriptor********/
    0x07,
    0x05,
    0x81,     /*b_ep_addr, We use D12 input ep1*/
            /*D7=1: input, so addr is 0x81*/
    0x03,    /*bm_attribute*/
    0x10,    /*w_max_packet_size*/
    0x00,
    0x0a,     /*b_interval: 10ms*/
    
    /**********Output Endpoint Descriptor********/
    0x07,
    0x05,
    0x01,     /*b_ep_addr, We use D12 input ep1*/
            /*D7=0: output, so addr is 0x81*/
    0x03,    /*bm_attribute*/
    0x10,    /*w_max_packet_size*/
    0x00,
    0x0a,     /*b_interval: 10ms*/
};

code uint8 language_id_str_desc[LANGUAGE_ID_STR_DESC_LEN] =
{
    0x04,
    0x03,
    0x09,    /*American language ID*/
    0x04,
};

code uint8 manu_str_desc[MANU_STR_DESC_LEN]= {
    82,        
    0x03,  
    0x35, 0x75, 
    0x11, 0x81, 
    0x08, 0x57,
    0x08, 0x57,
    0x84, 0x76, 
    0x55, 0x00, 
    0x53, 0x00,
    0x42, 0x00,
    0x13, 0x4e,
    0x3a, 0x53,
    0x20, 0x00,
    0x48, 0x00,
    0x74, 0x00,
    0x74, 0x00, 
    0x70, 0x00, 
    0x3a, 0x00, 
    0x2f, 0x00,
    0x2f, 0x00,
    0x67, 0x00, 
    0x72, 0x00, 
    0x6f, 0x00,
    0x75, 0x00,
    0x70, 0x00,
    0x2e, 0x00,
    0x65, 0x00, 
    0x64, 0x00, 
    0x6e, 0x00, 
    0x63, 0x00, 
    0x68, 0x00, 
    0x69, 0x00, 
    0x6e, 0x00,
    0x61, 0x00,
    0x2e, 0x00, 
    0x63, 0x00, 
    0x6f, 0x00, 
    0x6d, 0x00, 
    0x2f, 0x00, 
    0x39, 0x00, 
    0x33, 0x00, 
    0x2f, 0x00  
};

code uint8 product_str_desc[PRODUCT_STR_DESC]= {
    34,        
    0x03,     
    0x0a, 0x30, 
    0x08, 0x57,
    0x08, 0x57,
    0x59, 0x65, 
    0x60, 0x4f,
    0xa9, 0x73,
    0x55, 0x00, 
    0x53, 0x00, 
    0x42, 0x00,
    0x0b, 0x30,
    0x4b, 0x4e,
    0x55, 0x00,
    0x53, 0x00,
    0x42, 0x00,
    0x2e, 0x95,
    0xd8, 0x76
};

code uint8 serial_num_str_desc[SERIAL_NUM_STR_DESC]= {
    22,         
    0x03,       
    0x32, 0x00, 
    0x30, 0x00, 
    0x30, 0x00, 
    0x38, 0x00, 
    0x2d, 0x00, 
    0x30, 0x00,
    0x37, 0x00, 
    0x2d, 0x00, 
    0x31, 0x00, 
    0x32, 0x00  
};

void send_report(void) 
{
    uint8 Buf[8]={0,0,0,0,0,0,0,0};
    
    uint8 i=2;

    if(KeyPress & KEY1)
    {
        Buf[0]|=0x01; 
    }
    if(KeyPress & KEY2) 
    {
        Buf[0]|=0x02;  
    }
    if(KeyPress & KEY3)
    {
        Buf[0]|=0x04; 
    }
    if(KeyPress & KEY4) 
    {
        Buf[i]=0x59; 
        i++;  
    }
    if(KeyPress & KEY5) 
    {
        Buf[i]=0x5A; 
        i++;  
    }
    if(KeyPress & KEY6)  
    {
        Buf[i]=0x5B;  
        i++;  
    }
    if(KeyPress & KEY7)  
    {
        Buf[i]=0x39;  
        i++;  
    }
    if(KeyPress & KEY8)  
    {
        Buf[i]=0x53;  
    }
  
    d12_write_ep_buffer(3,8,Buf);
    ep1_in_is_busy=1;  
    KeyUp=0;
    KeyDown=0;
}

#endif /*CONFIG_KEYBOARD*/