#include "config.h"
#ifdef CONFIG_USB_MOUSE
#include "usb_core.h"
#include "key.h"
code uint8 device_desc[0x12] =
{
    0x12, /*bLength:18(0x12)*/
    0x01, /*bDescriptorType: device_desc:0x01*/
    
    0x10, /*USB1.1:0x0110*/
    0x01,
    
    0x00, /*bDeviceClass:0*/
    
    0x00, /*bDeviceSubClass:0*/
    
    0x00, /*bDeviceProtocal*/
    
    0x10, /*bMaxPacketSize, PDIUSBDS12 ep0 max is 16 bytes*/
    
    0x88, /*Vendor ID, 0x8888 for test only*/
    0x88,
    
    0x01, /*idProduct:0x0001*/
    0x00,
    
    0x00, /*bcdDevice*/
    0x01,
    
    0x01, /*iManufactuer*/
    
    0x02, /*iProduct*/
    
    0x03, /*Serial Number*/
    
    0x01, /*bNumConfiguration*/
};

code uint8 report_desc[] =
{

    0x05, 0x01, // USAGE_PAGE (Generic Desktop)

    0x09, 0x02, // USAGE (Mouse)

    0xa1, 0x01, // COLLECTION (Application)

    0x09, 0x01, //   USAGE (Pointer)

    0xa1, 0x00, //   COLLECTION (Physical)

    0x05, 0x09, //     USAGE_PAGE (Button)

    0x19, 0x01, //     USAGE_MINIMUM (Button 1)

    0x29, 0x03, //     USAGE_MAXIMUM (Button 3)

    0x15, 0x00, //     LOGICAL_MINIMUM (0)

    0x25, 0x01, //     LOGICAL_MAXIMUM (1)

    0x95, 0x03, //     REPORT_COUNT (3)

    0x75, 0x01, //     REPORT_SIZE (1)

    0x81, 0x02, //     INPUT (Data,Var,Abs)

    0x95, 0x01, //     REPORT_COUNT (1)

    0x75, 0x05, //     REPORT_SIZE (5)

    0x81, 0x03, //     INPUT (Cnst,Var,Abs)

    0x05, 0x01, //     USAGE_PAGE (Generic Desktop)

    0x09, 0x30, //     USAGE (X)

    0x09, 0x31, //     USAGE (Y)

    0x09, 0x38, //     USAGE (Wheel)
    
    0x15, 0x81, //     LOGICAL_MINIMUM (-127)
    0x25, 0x7f, //     LOGICAL_MAXIMUM (127)

    0x75, 0x08, //     REPORT_SIZE (8)

    0x95, 0x03, //     REPORT_COUNT (3)

    0x81, 0x06, //     INPUT (Data,Var,Rel)

    0xc0,       //   END_COLLECTION
    0xc0        // END_COLLECTION
};
    

code uint8 config_desc[CONFIG_DESC_ALL_LEN] =
{
    /**********Configuration Descriptor********/
    0x09,             /*b_length of config desc*/
    0x02,             /*b_descriptor_type, 0x02*/
    sizeof(config_desc) & 0xff,    /*w_total_length*/
    (sizeof(config_desc) >> 8) & 0xff,
    0x01,            /*b_num_interface, interface num in config desc*/
    0x01,            /*b_configuration*/
    0x00,             /*i_configration, string desc index*/
    0x80,            /*bm_attribtute, bus power supply, no suspend-resume*/
    0x32,            /*b_max_power, the max power need by the device*/
    
    /**********Interface Descriptor********/
    0x09,     /*b_length*/
    0x04,     /*b_descritpor_type*/
    0x00,     /*b_interface_number*/
    0x00,     /*b_alternate_setting*/
    0x01,    /*b_number_endpoints, non-zero ep number*/
    0x03,    /*b_interface_class, HID Class is 0x03*/
    0x01,    /*b_interface_sub_class*/
    0x02,     /*b_interface_protocal,keyboard:0x01, mouse:0x02*/
    0x00,      /*i_configuration*/
    
    /**********HID Descriptor********/
    0x09,     /*b_length*/
    0x21,     /*b_desc_type*/
    0x10,    /*bcdHID Protocal, 0x0110*/
    0x01,
    0x21,    /*b_country_code*/
    0x01,     /*b_number_descriptor, num of next level desc*/
    0x22,     /*b_desc_type, next level Report desc:0x22*/
    sizeof(report_desc) & 0xff,
    (sizeof(report_desc) >> 8) & 0xff,

    /**********Endpoint Descriptor********/
    0x07,
    0x05,
    0x81,     /*b_ep_addr, We use D12 input ep1*/
            /*D7=1: input, so addr is 0x81*/
    0x03,    /*bm_attribute*/
    0x10,    /*w_max_packet_size*/
    0x00,
    0x0a,     /*b_interval: 10ms*/
};

code uint8 language_id_str_desc[4] =
{
    0x04,
    0x03,
    0x09,    /*American language ID*/
    0x04,
};

code uint8 manu_str_desc[82]= {
    82,        
    0x03,  
    0x35, 0x75, 
    0x11, 0x81, 
    0x08, 0x57,
    0x08, 0x57,
    0x84, 0x76, 
    0x55, 0x00, 
    0x53, 0x00,
    0x42, 0x00,
    0x13, 0x4e,
    0x3a, 0x53,
    0x20, 0x00,
    0x48, 0x00,
    0x74, 0x00,
    0x74, 0x00, 
    0x70, 0x00, 
    0x3a, 0x00, 
    0x2f, 0x00,
    0x2f, 0x00,
    0x67, 0x00, 
    0x72, 0x00, 
    0x6f, 0x00,
    0x75, 0x00,
    0x70, 0x00,
    0x2e, 0x00,
    0x65, 0x00, 
    0x64, 0x00, 
    0x6e, 0x00, 
    0x63, 0x00, 
    0x68, 0x00, 
    0x69, 0x00, 
    0x6e, 0x00,
    0x61, 0x00,
    0x2e, 0x00, 
    0x63, 0x00, 
    0x6f, 0x00, 
    0x6d, 0x00, 
    0x2f, 0x00, 
    0x39, 0x00, 
    0x33, 0x00, 
    0x2f, 0x00  
};

code uint8 product_str_desc[34]= {
    34,       
    0x03,      
    0x0a, 0x30, 
    0x08, 0x57, 
    0x08, 0x57, 
    0x59, 0x65, 
    0x60, 0x4f, 
    0xa9, 0x73, 
    0x55, 0x00, 
    0x53, 0x00, 
    0x42, 0x00, 
    0x0b, 0x30, 
    0x4b, 0x4e, 
    0x55, 0x00, 
    0x53, 0x00, 
    0x42, 0x00, 
    0x20, 0x9f, 
    0x07, 0x68  
};

code uint8 serial_num_str_desc[22]= {
    22,         
    0x03,       
    0x32, 0x00, 
    0x30, 0x00, 
    0x30, 0x00,
    0x38, 0x00,
    0x2d, 0x00, 
    0x30, 0x00, 
    0x37, 0x00, 
    0x2d, 0x00, 
    0x30, 0x00, 
    0x37, 0x00  
};

void send_report() {

    uint8 Buf[4]= {0,0,0,0};
    
    KeyUp &= ~( KEY1 | KEY2 | KEY3 | KEY4 | KEY5 | KEY6);
    KeyDown &= ~(KEY1 | KEY2 | KEY3 | KEY4 | KEY5 | KEY6);

    if((KeyPress & (~(KEY7 | KEY8))) || KeyUp || KeyDown) {
        if(KeyPress & KEY1) { 
            Buf[1] = -10;  
        }
        if(KeyPress & KEY2) { 
            Buf[1] = 10;   
        }
        if(KeyPress & KEY3) { 
            Buf[2] = -10;   
        }
        if(KeyPress & KEY4) {
            Buf[2] = 10; 
        }
        if(KeyPress & KEY5) { 
            Buf[3] = -10;  
        }
        if(KeyPress & KEY6) { 
            Buf[3] = 10;  
        }
        if(KeyPress & KEY7) { 
            Buf[0] |= 0x01;  
        }
        if(KeyPress & KEY8) { 
            Buf[0] |= 0x02;  
        }
        
        d12_write_ep_buffer(3, 4, Buf);
        ep1_in_is_busy = 1; 
    }

    KeyUp = 0;
    KeyDown = 0;
}
#endif /*CONFIG_USB_MOUSE*/