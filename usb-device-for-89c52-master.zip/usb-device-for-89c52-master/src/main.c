#include <AT89X52.H>  
#include "key.h"
#include "led.h"
#include "config.h"
#include "uart.h"
#include "PDIUSBD12.h"
#include "usb_core.h"

extern void send_report(void);

#ifdef CONFIG_USB_KEYBOARD
void handle_keyboard_action()
{
     if (!ep1_in_is_busy) {
        KeyCanChange = 0; 
        if(KeyUp || KeyDown) {                
            send_report(); 
        }
        KeyCanChange = 1;
    }    
}
#endif

#ifdef CONFIG_USB_MOUSE
static void handle_mouse_action()
{
    LEDs = ~KeyPress;
    if (!ep1_in_is_busy) {
        KeyCanChange = 0; 
        if(KeyUp || KeyDown || KeyPress) {                
            send_report(); 
        }
        KeyCanChange = 1;
    }   
}
#endif

void main(void) { 

    char *version = "0.5";
    uint16 id;
    uint8 intp_src;
    
    EA = 1;
    init_keyboard(); 
    init_uart();
    id = d12_read_id();
    config_val = 0;
    
    puts("MJm usb learning\n Version:");
    puts(version);
    puts("\n");
    
    if (0x1012 == id) {
        puts("ID is correct!\n");
    } else {
        puts("ID is wrong\n");
    }
    
    usb_disconnect();
    usb_connect();
    
    while (1) {
        if (D12_GET_INT_PIN() == 0) {
            d12_write_command(READ_INTERRUPT_REGISTER);
            intp_src = d12_read_byte();
            if (intp_src & 0x80) {
                usb_bus_suspend();
            } else if (intp_src & 0x40) {
                usb_bus_reset();
            } else if (intp_src & 0x01) {
                usb_ep0_out();
            } else if (intp_src & 0x02) {
                usb_ep0_in();
            } else if (intp_src & 0x04) {
                usb_ep1_out();
            } else if (intp_src & 0x08) {
                usb_ep1_in();
            } else if (intp_src & 0x10) {
                usb_ep2_out();
            } else if (intp_src & 0x20) {
                usb_ep2_in();
            }
        }
        
        if (config_val != 0) {
#ifdef CONFIG_USB_MOUSE
            handle_mouse_action();
#endif
            
#ifdef CONFIG_USB_KEYBOARD
            handle_keyboard_action();
#endif         
    
        }
    }
}


