#include <at89x52.H>
#include "uart.h"
#include "type.h"
#include "config.h"

volatile uint8 Sending;

void init_uart(void)
{
    EA=0; 
    TMOD&=0x0F;  
    TMOD|=0x20;   
    SCON=0x50;  
    TH1=256-Fclk/(BitRate*12*16);  
    TL1=256-Fclk/(BitRate*12*16);
    PCON|=0x80; 
    ES=1; 
    TR1=1; 
    REN=1;  
    EA=1; 
}

void uart_isr(void) interrupt 4
{
    if(RI)   
    {
        RI=0;   
    }
    else      //������һ�ֽ�����
    {
        TI=0;
        Sending=0;  //�����ڷ��ͱ�־
    }
}

void putc(uint8 d)
{
#ifdef DEBUG
    SBUF=d;
    Sending=1;
    while(Sending);
#endif
}

void puts(uint8 * pd)
{
#ifdef DEBUG
    while((*pd)!='\0')
    {
        if (*pd == '\n') {
            putc('\r');
        }
        putc(*pd);
        pd++;
    }
#endif
}

void putint(uint32 x)
{
#ifdef DEBUG
    int8 i;
    uint8 display_buffer[10];

    for(i=9;i>=0;i--)
    {
        display_buffer[i]='0'+x%10;
        x/=10;
    }
    for(i=0;i<9;i++)
    {
        if(display_buffer[i]!='0')break;
    }
    for(;i<10;i++)
        putc(display_buffer[i]);
#endif
}

code uint8 HexTable[]={'0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F'};
#if 0
void putshort(uint16 x)
{
#ifdef DEBUG
    uint8 i;
    uint8 display_buffer[7];
    display_buffer[6]=0;
    display_buffer[0]='0';
    display_buffer[1]='x';
    for(i=5;i>=2;i--)
    {
        display_buffer[i]=HexTable[(x&0xf)];
        x>>=4;
    }
    puts(display_buffer);
#endif
}
#endif

void puthex(uint8 x)
{
#ifdef DEBUG
    putc('0');
    putc('x');
    putc(HexTable[x>>4]);
    putc(HexTable[x&0xf]);
    putc(' ');
#endif
}

#define USE_T2
uint32 uart_set_bit_rate(uint32 bit_rate)
{
    if(bit_rate<=230400)
    {
       RCAP2L=0x10000-(Fclk/(BitRate*32));
       RCAP2H=(0x10000-(Fclk/(BitRate*32)))>>8;
    }
    bit_rate=(Fclk/32)/(0x10000-((((uint32)RCAP2H)<<8)+RCAP2L));
    return 0;
}
