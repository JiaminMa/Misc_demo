#include "config.h"

#ifdef CONFIG_USB_SERIAL

#include "usb_core.h"
#include "key.h"

code uint8 device_desc[DEVICE_DESC_LEN] =
{
    0x12, /*bLength:18(0x12)*/
    0x01, /*bDescriptorType: device_desc:0x01*/
    
    0x10, /*USB1.1:0x0110*/
    0x01,
    
    0x02, /*bDeviceClass:0*/
    
    0x00, /*bDeviceSubClass:0*/
    
    0x00, /*bDeviceProtocal*/
    
    0x10, /*bMaxPacketSize, PDIUSBDS12 ep0 max is 16 bytes*/
    
    0x88, /*Vendor ID, 0x8888 for test only*/
    0x88,
    
    0x07, /*idProduct:0x0001*/
    0x00,
    
    0x00, /*bcdDevice*/
    0x01,
    
    0x01, /*iManufactuer*/
    
    0x02, /*iProduct*/
    
    0x03, /*Serial Number*/
    
    0x01, /*bNumConfiguration*/
};

code uint8 config_desc[CONFIG_DESC_ALL_LEN] =
{
    /**********Configuration Descriptor********/
    0x09,             /*b_length of config desc*/
    0x02,             /*b_descriptor_type, 0x02*/
    sizeof(config_desc) & 0xff,    /*w_total_length*/
    (sizeof(config_desc) >> 8) & 0xff,
    0x02,            /*b_num_interface, interface num in config desc*/
    0x01,            /*b_configuration*/
    0x00,             /*i_configration, string desc index*/
    0x80,            /*bm_attribtute, bus power supply, no suspend-resume*/
    0x32,            /*b_max_power, the max power need by the device*/
    
    /**********CDC Class Descriptor********/
    0x09,           /*bLength*/
    0x04,           /*bDescriptorType*/
    0x00,           /*bInterfaceNum*/
    0x00,           /*bAlternateSetting*/
    0x01,           /*bNumEndpoints, num of none-zero endpoint*/
    0x02,           /*bInterfaceClass*/
    0x02,           /*bInterfaceSubClass*/
    0x01,           /*bInterfaceProtocal, Common AT Command:0x01*/
    0x00,           /*iConfiguration*/
    
    /**********Functional Descriptor********/
    0x05,       /*bFuntionLength*/
    0x24,       /*bDescriptorType*/
    0x00,       /*bDescriptorSubType*/
    0x10,       /*bcdCDC*/
    0x01,
    
    /**********Call Manager Functional Descriptor********/
    0x05,       /*bFunctionalLength*/
    0x24,       /*bDescriptorType*/
    0x01,       /*bDescriptorSubType*/
    0x00,       /*bmCapabilities*/
    0x00,       /*bDataInterface*/
    
    /**********Abstract Control Manager Functional Descriptor********/
    0x04,
    0x24,
    0x02,       /*bDescriptorSubType*/
    0x02,       /*bmCapabilities*/
    
    /**********Union Functional Descriptor********/
    0x05,       /*bFunctionalLength*/
    0x24,       /*bDescriptorType*/
    0x06,       /*bDescriptorSubType*/
    0x00,       /*MasterInterface, CDC interface code:0*/
    0x01,       /*SlaveInterface, Data interface code:1*/

    /**********Input Endpoint Descriptor********/
    0x07,
    0x05,
    0x81,     /*b_ep_addr, We use D12 input ep1*/
            /*D7=1: input, so addr is 0x81*/
    0x03,    /*bm_attribute*/
    0x10,    /*w_max_packet_size*/
    0x00,
    0x0a,     /*b_interval: 10ms*/
    
    /**********Data Interface Descriptor********/
    0x09,   /*bLength*/
    0x04,   /*bDescriptorType*/
    0x01,   /*bInterfaceNumber*/
    0x00,   /*bAlternateSetting*/
    0x02,   /*bNumEndpoints*/
    0x0a,   /*bInterfaceClass*/
    0x00,   /*bInterfaceSubClass*/
    0x00,   /*bInterfaceProtocal*/
    0x00,   /*iConfiguration*/
    
    /**********Data Interface Descriptor********/
    /**********Input Endpoint2 Descriptor********/
    0x07,   /*bLength*/
    0x05,   /*bDescriptorType*/
    0x82,   /*bEndpointAddress, Input:8, epnum:2*/
    0x02,   /*bAttribute, Bulk Endpoint*/
    0x40,   /*wMaxPacketSize*/
    0x00,
    0x00,   /*bInterval*/
    
    /**********Data Interface Descriptor********/
    /**********Output Endpoint2 Descriptor********/  
    0x07,
    0x05,
    0x02,
    0x02,
    0x40,
    0x40,
    0x00,
};

code uint8 language_id_str_desc[LANGUAGE_ID_STR_DESC_LEN] =
{
    0x04,
    0x03,
    0x09,    /*American language ID*/
    0x04,
};

code uint8 manu_str_desc[MANU_STR_DESC_LEN]= {
    82,        
    0x03,  
    0x35, 0x75, 
    0x11, 0x81, 
    0x08, 0x57,
    0x08, 0x57,
    0x84, 0x76, 
    0x55, 0x00, 
    0x53, 0x00,
    0x42, 0x00,
    0x13, 0x4e,
    0x3a, 0x53,
    0x20, 0x00,
    0x48, 0x00,
    0x74, 0x00,
    0x74, 0x00, 
    0x70, 0x00, 
    0x3a, 0x00, 
    0x2f, 0x00,
    0x2f, 0x00,
    0x67, 0x00, 
    0x72, 0x00, 
    0x6f, 0x00,
    0x75, 0x00,
    0x70, 0x00,
    0x2e, 0x00,
    0x65, 0x00, 
    0x64, 0x00, 
    0x6e, 0x00, 
    0x63, 0x00, 
    0x68, 0x00, 
    0x69, 0x00, 
    0x6e, 0x00,
    0x61, 0x00,
    0x2e, 0x00, 
    0x63, 0x00, 
    0x6f, 0x00, 
    0x6d, 0x00, 
    0x2f, 0x00, 
    0x39, 0x00, 
    0x33, 0x00, 
    0x2f, 0x00  
};

code uint8 product_str_desc[PRODUCT_STR_DESC]= {
    38,
    0x03,
    0x0a, 0x30,
    0x08, 0x57,
    0x08, 0x57,
    0x59, 0x65,
    0x60, 0x4f, 
    0xa9, 0x73, 
    0x55, 0x00, 
    0x53, 0x00, 
    0x42, 0x00, 
    0x0b, 0x30, 
    0x4b, 0x4e,
    0x20, 0x00, 
    0x55, 0x00, 
    0x53, 0x00, 
    0x42, 0x00, 
    0x6c, 0x8f, 
    0x32, 0x4e,
    0xe3, 0x53  
};

code uint8 serial_num_str_desc[SERIAL_NUM_STR_DESC]= {
    22,         
    0x03,       
    0x32, 0x00, 
    0x30, 0x00, 
    0x30, 0x00, 
    0x38, 0x00, 
    0x2d, 0x00, 
    0x30, 0x00,
    0x37, 0x00, 
    0x2d, 0x00, 
    0x31, 0x00, 
    0x32, 0x00  
};


#endif /*CONFIG_USB_SERIAL*/