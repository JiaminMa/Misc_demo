#include "PDIUSBd12.h"

uint8 d12_read_byte()
{
    uint8 temp;
    D12_SET_DATA_ADDR();
    D12_CLR_RD();
    temp = D12_GET_DATA();
    D12_SET_RD();
    return temp;
}

uint16 d12_read_id()
{
    uint16 id;
    d12_write_command(READ_ID);
    id = d12_read_byte();
    id |= ((uint16)d12_read_byte()) << 8;
    return id;
}

static void d12_write_byte_impl(uint8 val, d12_data_type type) 
{
    switch(type) {
    case COMMAND:
        D12_SET_COMMAND_ADDR();
        break;
    case DATA:
        D12_SET_DATA_ADDR();
        break;
    default:
        break;
    }
    
    D12_CLR_WR();
    D12_SET_PORT_OUT();
    D12_SET_DATA(val);
    D12_SET_WR();
    D12_SET_PORT_IN();
}

void d12_write_command(uint8 command)
{
    d12_write_byte_impl(command, COMMAND);
}

void d12_write_byte(uint8 value)
{
    d12_write_byte_impl(value, DATA);
}

void d12_select_endpoint(uint8 endp)
{
    d12_write_command(0x00 + endp);
}

uint8 d12_read_ep_buffer(uint8 endp, uint8 len, uint8 *buf)
{
    uint8 i, j = 0;
    d12_select_endpoint(endp);
    d12_write_command(D12_READ_BUFFER);
    d12_read_byte();
    j = d12_read_byte();
    if (j > len) {
        j = len;
    }

    puts("read endpoint");
    putint(endp/2);
    puts(" buffer ");
    putint(j);
    puts(" bytes\n");
    
    for (i = 0; i < j; i++) {
        D12_CLR_RD();
        *(buf + i) = D12_GET_DATA();
        D12_SET_RD();
        puthex(*(buf + i));
        
        if (((i + 1) % 16) == 0) {
            puts("\n");
        }
    }
    
    if ((j % 16) != 0) {
        puts("\n");
    }
    
    return j;
}

void d12_clear_buffer()
{
    d12_write_command(D12_CLEAR_BUFFER);
}

void d12_acknowledge_setup(void)
{
    d12_select_endpoint(1);
    d12_write_command(D12_ACKNOWLEDGE_SETUP);
    d12_select_endpoint(0);
    d12_write_command(D12_ACKNOWLEDGE_SETUP);
}

uint8 d12_read_ep_last_stat(uint8 endp) 
{
    d12_write_command(0x40 + endp); 
    return d12_read_byte();
}

void d12_validate_buffer()
{
    d12_write_command(D12_VALIDATE_BUFFER);
}

uint8 d12_write_ep_buffer(uint8 endp, uint8 len, uint8 *buf)
{
    uint8 i;
    d12_select_endpoint(endp);
    d12_write_command(D12_WRITE_BUFFER);
    d12_write_byte(0);
    d12_write_byte(len);

    puts("Write endpoint");
    putint(endp / 2);
    puts(" buffer ");
    putint(len);
    puts(" bytes...\n");

    D12_SET_PORT_OUT();
    
    for(i = 0; i < len; i++) {
        D12_CLR_WR();
        d12_write_byte(*(buf + i));
        D12_SET_WR();
    
        puthex(*(buf +i));
        if (((i + 1) % 16) == 0) {
            puts("\n");
        }
    }
    
    if ((len % 16) != 0) {
        puts("\n");
    }
    
    D12_SET_PORT_IN();
    d12_validate_buffer();
    return len;
}

void d12_set_address(uint8 addr)
{
    d12_write_command(D12_SET_ADDRESS_ENABLE);
    d12_write_byte(0x80 |  addr);
}

void d12_set_ep_enable(uint8 enable)
{
    d12_write_command(D12_SET_ENDPOINT_ENABLE);
    if (enable != 0)  {
        d12_write_byte(0x01);
    } else {
        d12_write_byte(0x00);
    }
}
